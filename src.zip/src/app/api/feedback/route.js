import { NextResponse } from 'next/server';
import dbConnect from '@/lib/dbConnect';
import Feedback from '@/lib/models/Feedback';
import sendEmail from '@/lib/sendEmail';
import { errorResponse } from '@/lib/auth';

export const dynamic = 'force-dynamic';

// Escapes HTML special characters so user-submitted text (name, email,
// message) can never be interpreted as HTML/script markup when it's
// embedded inside the feedback notification email below. Without this,
// someone could put raw HTML tags in the feedback form and have them
// rendered as-is in the email that lands in an admin's inbox.
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export async function POST(request) {
  await dbConnect();
  try {
    const { name, email, message } = await request.json();
    if (!name || !email || !message) {
      return NextResponse.json({ success: false, message: 'Please fill in all fields' }, { status: 400 });
    }

    await Feedback.create({ name, email, message });

    const safeName = escapeHtml(name);
    const safeEmail = escapeHtml(email);
    const safeMessage = escapeHtml(message).replace(/\n/g, '<br />');

    await sendEmail({
      email: process.env.SMTP_USER,
      subject: `PolyAttend Feedback — ${name}`,
      message: `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px;">
          <h2 style="color: #1a6b4a;">New Feedback — PolyAttend</h2>
          <p><strong>Name:</strong> ${safeName}</p>
          <p><strong>Email:</strong> ${safeEmail}</p>
          <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 16px 0;" />
          <p><strong>Message:</strong></p>
          <p style="background: #f8fafc; padding: 12px; border-radius: 8px;">${safeMessage}</p>
        </div>`,
    });

    return NextResponse.json({ success: true, message: 'Feedback submitted successfully! Thank you.' }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}